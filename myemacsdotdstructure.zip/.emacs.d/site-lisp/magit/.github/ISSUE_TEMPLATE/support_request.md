---
name: Support request
about: Do NOT open support requests here
---

DO NOT use this issue tracker for support requests.

Please use the Emacs StackExchange site [1] or Emacs subreddit [2] for support requests.

But before you do that please read the list of frequently asked questions [3] and consult the manual [4] and a search engine.

We only use this issue tracker for feature requests and bug reports.

  [1]: https://emacs.stackexchange.com
  [2]: https://www.reddit.com/r/emacs
  [3]: https://magit.vc/manual/magit/FAQ.html
  [4]: https://magit.vc/manual/magit/#Top
